<h1 class="page-title">Grafik Saldo</h1>

<div class="card">
    <div class="actions-bar">
        <div class="chart-filters" id="chart-filter-buttons">
            <a href="index.php?page=graph&start_date=<?= date('Y-m-d', strtotime('-7 days')) ?>&end_date=<?= date('Y-m-d') ?>" class="btn" data-period="7">7 Hari</a>
            <a href="index.php?page=graph&start_date=<?= date('Y-m-d', strtotime('-30 days')) ?>&end_date=<?= date('Y-m-d') ?>" class="btn" data-period="30">30 Hari</a>
            <form action="index.php" method="get" style="display: contents;">
                <input type="hidden" name="page" value="graph">
                <input type="date" name="start_date" id="custom_start_date" value="<?= htmlspecialchars($start_date_filter ?? '') ?>">
                <input type="date" name="end_date" id="custom_end_date" value="<?= htmlspecialchars($end_date_filter ?? '') ?>">
                <button type="submit" class="btn" data-period="custom">Terapkan</button>
            </form>
        </div>
    </div>
    <div style="height: 450px;">
        <canvas id="balanceChart"></canvas>
    </div>
</div>
<div style="text-align: center;">
    <a href="index.php" class="btn">Kembali ke Halaman Utama</a>
</div>