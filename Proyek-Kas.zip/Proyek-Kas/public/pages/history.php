<h1 class="page-title">Riwayat Transaksi</h1>

<div class="card">
     <form action="index.php?page=history" method="post" id="history-form">
        <!-- PERBAIKAN: Menambahkan hidden input untuk memberitahu halaman mana yang aktif -->
        <input type="hidden" name="current_page" value="history">
        <div class="actions-bar">
            <div class="transaction-type-filters">
                <!-- FITUR BARU: Filter berdasarkan jenis transaksi -->
                <a href="?page=history&jenis_filter=semua" class="btn <?= $jenis_filter == 'semua' ? 'active' : '' ?>">Semua</a>
                <a href="?page=history&jenis_filter=debit" class="btn <?= $jenis_filter == 'debit' ? 'active' : '' ?>">Debit Saja</a>
                <a href="?page=history&jenis_filter=credit" class="btn <?= $jenis_filter == 'credit' ? 'active' : '' ?>">Kredit Saja</a>
            </div>
            <div class="bulk-actions">
                <button type="submit" name="hapus_massal" class="btn btn-danger"><span class="icon-btn">🗑️</span> Hapus Terpilih</button>
            </div>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th><input type="checkbox" id="select-all"></th>
                        <th>No.</th>
                        <th class="sortable"><a href="?page=history&sort=tanggal&order=<?= $sort_by == 'tanggal' ? $next_order : 'desc' ?>">Tanggal <?= $sort_by == 'tanggal' ? ($order == 'DESC' ? '▼' : '▲') : '' ?></a></th>
                        <th>Keterangan</th>
                        <th class="sortable"><a href="?page=history&sort=nama_pengisi&order=<?= $sort_by == 'nama_pengisi' ? $next_order : 'asc' ?>">Oleh <?= $sort_by == 'nama_pengisi' ? ($order == 'ASC' ? '▲' : '▼') : '' ?></a></th>
                        <th class="sortable"><a href="?page=history&sort=jumlah&order=<?= $sort_by == 'jumlah' ? $next_order : 'desc' ?>">Jumlah <?= $sort_by == 'jumlah' ? ($order == 'DESC' ? '▼' : '▲') : '' ?></a></th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($catatan): 
                        $nomor = 1;
                        foreach ($catatan as $row): ?>
                    <tr>
                        <td><input type="checkbox" name="delete_ids[]" value="<?= $row['id'] ?>" class="row-checkbox"></td>
                        <td><?= $nomor++ ?></td>
                        <td><?= date("d-m-Y", strtotime($row['tanggal'])) ?><br><small><?= date("l", strtotime($row['tanggal'])) ?></small></td>
                        <td><?= htmlspecialchars($row['keterangan']) ?></td>
                        <td><?= htmlspecialchars($row['nama_pengisi']) ?></td>
                        <td><span class="<?= $row['jenis'] ?>"><?= ($row['jenis'] == 'debit' ? '▲' : '▼') ?> Rp <?= number_format($row['jumlah'], 0, ',', '.') ?></span></td>
                        <td><a href="index.php?page=history&hapus=<?= $row['id'] ?>" onclick="return confirm('Anda yakin?');" class="btn icon-btn" style="background: transparent;">🗑️</a></td>
                    </tr>
                    <?php endforeach; else: ?>
                    <tr><td colspan="7" style="text-align:center; padding: 3rem;">Belum ada data transaksi untuk filter ini.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </form>
</div>
<div style="text-align: center;">
    <a href="index.php" class="btn">Kembali ke Halaman Utama</a>
</div>