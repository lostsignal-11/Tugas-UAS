<div class="main-header">
    <h1>MAALI</h1>
</div>

<div class="summary">
    <div class="card">
        <h3>Total Pemasukan (Debit)</h3>
        <p class="debit highlight-number">Rp <?= number_format(array_sum(array_column(array_filter($catatan, fn($c)=>$c['jenis']=='debit'), 'jumlah')), 0, ',', '.') ?></p>
    </div>
    <div class="card">
        <h3>Total Pengeluaran (Credit)</h3>
        <p class="credit highlight-number">Rp <?= number_format(array_sum(array_column(array_filter($catatan, fn($c)=>$c['jenis']=='credit'), 'jumlah')), 0, ',', '.') ?></p>
    </div>
    <div class="card">
        <h3>Saldo Akhir</h3>
        <p class="saldo highlight-number">Rp <?= number_format(array_sum(array_column(array_filter($catatan, fn($c)=>$c['jenis']=='debit'), 'jumlah')) - array_sum(array_column(array_filter($catatan, fn($c)=>$c['jenis']=='credit'), 'jumlah')), 0, ',', '.') ?></p>
    </div>
</div>

<?php if (isset($_SESSION['message'])): ?>
    <div id="notification" class="alert alert-<?= htmlspecialchars($_SESSION['message_type']) ?>"><?= htmlspecialchars($_SESSION['message']) ?></div>
    <?php unset($_SESSION['message'], $_SESSION['message_type']); ?>
<?php endif; ?>

<div class="main-nav">
    <a href="index.php?page=history">
        <div class="card">📖 Riwayat Transaksi</div>
    </a>
    <a href="index.php?page=graph">
        <div class="card">📊 Lihat Grafik Saldo</div>
    </a>
</div>

<div class="card">
    <h2 style="text-align: center; margin-top: 0;">Tambah Transaksi Baru</h2>
    <form action="index.php" method="post" class="transaction-form">
        <input type="hidden" name="tambah_transaksi" value="1">
        <div class="form-group">
            <label for="tanggal">Tanggal Transaksi</label>
            <input id="tanggal" type="date" name="tanggal" value="<?= date('Y-m-d') ?>" required>
        </div>
        <div class="form-group">
            <label for="nama_pengisi">Nama Pengisi</label>
            <input id="nama_pengisi" type="text" name="nama_pengisi" placeholder="cth: Farhan" required>
        </div>
        <div class="form-group full-width">
            <label for="keterangan">Keterangan</label>
            <input id="keterangan" type="text" name="keterangan" placeholder="cth: Gaji bulanan, bayar listrik" required>
        </div>
        <div class="form-group">
            <label for="jenis">Jenis Transaksi</label>
            <select id="jenis" name="jenis" required>
                <option value="debit">Debit (Uang Masuk)</option>
                <option value="credit">Credit (Uang Keluar)</option>
            </select>
        </div>
        <div class="form-group">
            <label for="formatted_jumlah">Jumlah (Rp)</label>
            <input id="formatted_jumlah" type="text" placeholder="cth: 1.000.000" required inputmode="numeric">
            <input type="hidden" name="jumlah" id="actual_jumlah">
        </div>
        <button type="submit" class="submit-btn">Simpan Transaksi</button>
    </form>
</div>