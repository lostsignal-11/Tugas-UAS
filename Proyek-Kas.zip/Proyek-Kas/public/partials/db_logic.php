<?php
// --- KONFIGURASI ---
$host = 'db';
$dbname = 'kas_db';
$user = 'user';
$pass = 'password';
$charset = 'utf8mb4';

// --- KONEKSI DATABASE ---
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=$charset", $user, $pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
} catch (\PDOException $e) {
    die("Gagal terhubung ke database. Pastikan layanan Docker berjalan dengan baik. Error: " . $e->getMessage());
}

// --- BUAT TABEL JIKA BELUM ADA ---
$pdo->exec("CREATE TABLE IF NOT EXISTS catatan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tanggal DATE NOT NULL,
    keterangan VARCHAR(255) NOT NULL,
    nama_pengisi VARCHAR(100) NOT NULL,
    jenis ENUM('debit', 'credit') NOT NULL,
    jumlah DECIMAL(15, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// --- LOGIKA PEMROSESAN FORM (DELETE, ADD) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $redirect_page = $_POST['current_page'] ?? 'home';
    // Hapus Massal
    if (isset($_POST['hapus_massal']) && !empty($_POST['delete_ids'])) {
        $ids_to_delete = $_POST['delete_ids'];
        if (is_array($ids_to_delete)) {
            $placeholders = implode(',', array_fill(0, count($ids_to_delete), '?'));
            $sql = "DELETE FROM catatan WHERE id IN ($placeholders)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($ids_to_delete);
            $_SESSION['message'] = "Data yang dipilih berhasil dihapus.";
            $_SESSION['message_type'] = "sukses";
        }
    }
    // Tambah Data
    elseif (isset($_POST['tambah_transaksi'])) {
        $jumlah_murni = $_POST['jumlah'];
        $sql = "INSERT INTO catatan (tanggal, keterangan, nama_pengisi, jenis, jumlah) VALUES (?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$_POST['tanggal'], $_POST['keterangan'], $_POST['nama_pengisi'], $_POST['jenis'], $jumlah_murni]);
        $_SESSION['message'] = "Transaksi berhasil disimpan!";
        $_SESSION['message_type'] = "sukses";
    }
    header("Location: index.php?page=" . $redirect_page);
    exit;
}
// Hapus Tunggal
if (isset($_GET['hapus'])) {
    $stmt = $pdo->prepare("DELETE FROM catatan WHERE id = ?");
    $stmt->execute([$_GET['hapus']]);
    $_SESSION['message'] = "Transaksi berhasil dihapus.";
    $_SESSION['message_type'] = "sukses";
    // PERBAIKAN: Redirect kembali ke halaman riwayat
    header("Location: index.php?page=history");
    exit;
}

// --- PENGATURAN FILTER DAN SORTING ---
$sort_columns = ['tanggal', 'nama_pengisi', 'jumlah'];
$sort_by = isset($_GET['sort']) && in_array($_GET['sort'], $sort_columns) ? $_GET['sort'] : 'tanggal';
$order = isset($_GET['order']) && strtolower($_GET['order']) == 'asc' ? 'ASC' : 'DESC';
$next_order = $order == 'DESC' ? 'asc' : 'desc';

// Filter baru berdasarkan jenis transaksi
$jenis_filter = $_GET['jenis_filter'] ?? 'semua';

// --- AMBIL DATA DARI DATABASE ---
$sql_catatan = "SELECT * FROM catatan";
$params = [];
if ($jenis_filter !== 'semua') {
    $sql_catatan .= " WHERE jenis = ?";
    $params[] = $jenis_filter;
}
$sql_catatan .= " ORDER BY $sort_by $order, id $order";
$stmt_catatan = $pdo->prepare($sql_catatan);
$stmt_catatan->execute($params);
$catatan = $stmt_catatan->fetchAll();

// --- PERSIAPAN DATA UNTUK GRAFIK SALDO ---
$start_date_filter = $_GET['start_date'] ?? null;
$end_date_filter = $_GET['end_date'] ?? null;

$chart_labels = [];
$chart_saldo = [];

$saldo_awal = 0;
$sql_saldo_awal = "SELECT 
    (SELECT COALESCE(SUM(jumlah), 0) FROM catatan WHERE jenis = 'debit' AND tanggal < ?) - 
    (SELECT COALESCE(SUM(jumlah), 0) FROM catatan WHERE jenis = 'credit' AND tanggal < ?) as saldo_awal";
$stmt_saldo_awal = $pdo->prepare($sql_saldo_awal);
$tanggal_mulai_grafik = $start_date_filter ?? '1970-01-01';
$stmt_saldo_awal->execute([$tanggal_mulai_grafik, $tanggal_mulai_grafik]);
$hasil_saldo_awal = $stmt_saldo_awal->fetch();
if ($hasil_saldo_awal) {
    $saldo_awal = $hasil_saldo_awal['saldo_awal'];
}

$daily_summary = [];
$sql_grafik = "SELECT * FROM catatan";
$params_grafik = [];
if ($start_date_filter && $end_date_filter) {
    $sql_grafik .= " WHERE tanggal BETWEEN ? AND ?";
    $params_grafik[] = $start_date_filter;
    $params_grafik[] = $end_date_filter;
}
$sql_grafik .= " ORDER BY tanggal ASC, id ASC";
$stmt_grafik = $pdo->prepare($sql_grafik);
$stmt_grafik->execute($params_grafik);
$data_grafik = $stmt_grafik->fetchAll();

foreach($data_grafik as $row) {
    $date = $row['tanggal'];
    if (!isset($daily_summary[$date])) {
        $daily_summary[$date] = 0;
    }
    if ($row['jenis'] == 'debit') {
        $daily_summary[$date] += $row['jumlah'];
    } else {
        $daily_summary[$date] -= $row['jumlah'];
    }
}

$saldo_berjalan = $saldo_awal;
foreach($daily_summary as $date => $net_change) {
    $saldo_berjalan += $net_change;
    $chart_labels[] = date("d-m-Y", strtotime($date));
    $chart_saldo[] = $saldo_berjalan;
}
