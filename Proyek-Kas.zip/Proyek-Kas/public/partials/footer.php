</div>

    <script>
        // Theme Switcher
        const themeToggle = document.getElementById('theme-toggle');
        const currentTheme = localStorage.getItem('theme') ? localStorage.getItem('theme') : null;

        if (currentTheme) {
            document.body.classList.add(currentTheme);
            if (currentTheme === 'light-mode') {
                themeToggle.innerHTML = '☀️';
            } else {
                themeToggle.innerHTML = '🌙';
            }
        } else {
            // Default to dark mode
            document.body.classList.add('dark-mode');
            themeToggle.innerHTML = '🌙';
        }

        themeToggle.addEventListener('click', () => {
            if (document.body.classList.contains('dark-mode')) {
                document.body.classList.remove('dark-mode');
                document.body.classList.add('light-mode');
                themeToggle.innerHTML = '☀️';
                localStorage.setItem('theme', 'light-mode');
            } else {
                document.body.classList.remove('light-mode');
                document.body.classList.add('dark-mode');
                themeToggle.innerHTML = '🌙';
                localStorage.setItem('theme', 'dark-mode');
            }
            // Redraw chart if it exists, to adapt to new theme colors
            if (typeof balanceChart !== 'undefined') {
                balanceChart.destroy();
                renderChart();
            }
        });

        // Notifikasi
        const notification = document.getElementById('notification');
        if (notification) { setTimeout(() => { notification.style.opacity = '0'; setTimeout(() => notification.remove(), 500); }, 5000); }

        // Format Angka
        const formattedInput = document.getElementById('formatted_jumlah');
        if(formattedInput) {
            const actualInput = document.getElementById('actual_jumlah');
            formattedInput.addEventListener('input', (e) => {
                let rawValue = e.target.value.replace(/[^0-9]/g, '');
                actualInput.value = rawValue;
                e.target.value = rawValue ? new Intl.NumberFormat('id-ID').format(rawValue) : '';
            });
        }

        // Pilih Semua Checkbox
        const selectAllCheckbox = document.getElementById('select-all');
        if(selectAllCheckbox) {
            selectAllCheckbox.addEventListener('change', function(e) {
                document.querySelectorAll('.row-checkbox').forEach(checkbox => checkbox.checked = e.target.checked);
            });
        }
        
        // Highlight Tombol Filter Aktif
        const urlParams = new URLSearchParams(window.location.search);
        const startDate = urlParams.get('start_date');
        const endDate = urlParams.get('end_date');
        const sevenDaysAgo = '<?= date('Y-m-d', strtotime('-7 days')) ?>';
        const thirtyDaysAgo = '<?= date('Y-m-d', strtotime('-30 days')) ?>';
        const today = '<?= date('Y-m-d') ?>';

        if (startDate === sevenDaysAgo && endDate === today) {
            document.querySelector('[data-period="7"]').classList.add('active');
        } else if (startDate === thirtyDaysAgo && endDate === today) {
            document.querySelector('[data-period="30"]').classList.add('active');
        } else if (startDate && endDate) {
            document.querySelector('[data-period="custom"]').classList.add('active');
        }

        // Grafik Saldo Chart.js
        const chartCanvas = document.getElementById('balanceChart');
        let balanceChart;

        function renderChart() {
            if (chartCanvas) {
                const isDarkMode = document.body.classList.contains('dark-mode');
                const textColor = isDarkMode ? 'rgba(255,255,255,0.7)' : '#6C757D';
                const gridColor = isDarkMode ? 'rgba(255,255,255,0.1)' : '#DEE2E6';
                const accentColor = isDarkMode ? 'rgba(201, 176, 55, 1)' : 'rgba(181, 149, 0, 1)';
                
                const ctx = chartCanvas.getContext('2d');
                const gradient = ctx.createLinearGradient(0, 0, 0, 400);
                gradient.addColorStop(0, isDarkMode ? 'rgba(201, 176, 55, 0.4)' : 'rgba(181, 149, 0, 0.4)');
                gradient.addColorStop(1, isDarkMode ? 'rgba(201, 176, 55, 0)' : 'rgba(181, 149, 0, 0)');

                balanceChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: <?= json_encode($chart_labels) ?>,
                        datasets: [{
                            label: 'Saldo Akhir',
                            data: <?= json_encode($chart_saldo) ?>,
                            borderColor: accentColor,
                            backgroundColor: gradient,
                            fill: true,
                            tension: 0.4,
                            pointBackgroundColor: '#fff',
                            pointBorderColor: accentColor
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                ticks: { color: textColor, callback: (value) => 'Rp ' + new Intl.NumberFormat('id-ID').format(value) },
                                grid: { color: gridColor }
                            },
                            x: {
                                ticks: { color: textColor },
                                grid: { color: gridColor }
                            }
                        },
                        plugins: {
                            legend: { display: false },
                            tooltip: {
                                callbacks: {
                                    label: (context) => 'Saldo: Rp ' + new Intl.NumberFormat('id-ID').format(context.parsed.y)
                                }
                            }
                        }
                    }
                });
            }
        }
        
        renderChart();

    </script>
</body>
</html>