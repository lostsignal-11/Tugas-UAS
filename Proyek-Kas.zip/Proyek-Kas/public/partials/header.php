<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Amiri:wght@700&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --bg-start-dark: #1D2B34;
            --bg-end-dark: #0F171E;
            --card-bg-dark: rgba(255, 255, 255, 0.03);
            --card-border-dark: rgba(255, 255, 255, 0.1);
            --text-primary-dark: #EAECEF;
            --text-secondary-dark: #AAB8C2;
            --accent-gold-dark: #C9B037;

            --bg-start-light: #F4F7F9;
            --bg-end-light: #E9EDF2;
            --card-bg-light: #FFFFFF;
            --card-border-light: #DEE2E6;
            --text-primary-light: #212529;
            --text-secondary-light: #6C757D;
            --accent-gold-light: #B59500;
            
            --debit-color: #2ECC71;
            --credit-color: #E74C3C;
            --shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            --border-radius: 16px;
        }
        body { 
            font-family: 'Poppins', sans-serif; 
            margin: 0;
            padding: 2rem;
            min-height: 100vh;
            transition: background-color 0.3s, color 0.3s;
        }
        body.dark-mode {
            background: linear-gradient(135deg, var(--bg-start-dark), var(--bg-end-dark));
            color: var(--text-primary-dark);
        }
        body.light-mode {
            background: linear-gradient(135deg, var(--bg-start-light), var(--bg-end-light));
            color: var(--text-primary-light);
        }
        .container { max-width: 1200px; margin: auto; }
        .card {
            padding: 2rem; 
            border-radius: var(--border-radius); 
            margin-bottom: 2rem;
            transition: background-color 0.3s, border-color 0.3s;
        }
        body.dark-mode .card {
            background-color: var(--card-bg-dark);
            backdrop-filter: blur(20px);
            box-shadow: var(--shadow);
            border: 1px solid var(--card-border-dark);
        }
        body.light-mode .card {
            background-color: var(--card-bg-light);
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            border: 1px solid var(--card-border-light);
        }
        .main-header h1 {
            font-family: 'Amiri', serif;
            font-size: 4rem;
            font-weight: 700;
            margin: 0 0 2rem 0;
            text-align: center;
            color: #fff; /* Warna teks putih untuk kedua mode */
            text-shadow: 0 0 15px var(--accent-gold-dark), 0 0 2px #333; /* Highlight emas dengan outline gelap tipis agar terbaca di background terang */
        }
        .page-title {
            font-size: 2.5rem;
            font-weight: 600;
            text-align: center;
            margin-bottom: 2rem;
            text-transform: uppercase;
        }
        body.dark-mode .page-title { color: var(--accent-gold-dark); }
        body.light-mode .page-title { color: var(--accent-gold-light); }

        /* Other styles */
        .theme-switcher { 
            position: fixed;
            top: 1.5rem; 
            right: 1.5rem; 
            z-index: 9999;
        }
        .btn { padding: 0.6rem 1.2rem; border-radius: 8px; border: none; cursor: pointer; font-weight: 500; text-decoration: none; display: inline-flex; align-items: center; gap: 0.5rem; transition: all 0.2s ease-in-out; }
        body.dark-mode .btn { background-color: rgba(255,255,255,0.1); color: var(--text-primary-dark); }
        body.light-mode .btn { background-color: #E9ECEF; color: var(--text-primary-light); }
        body.dark-mode .btn:hover { background-color: rgba(255,255,255,0.2); transform: translateY(-2px); }
        body.light-mode .btn:hover { background-color: #DEE2E6; transform: translateY(-2px); }
        .btn.active { transform: scale(1.05); }
        body.dark-mode .btn.active { background-color: var(--accent-gold-dark); color: #000; }
        body.light-mode .btn.active { background-color: var(--accent-gold-light); color: #fff; }
        .btn-danger { background-color: var(--credit-color); color: white; }
        .icon-btn { font-size: 1.2rem; }
        
        /* Form Styles */
        .transaction-form { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; }
        .form-group { display: flex; flex-direction: column; }
        .form-group.full-width { grid-column: 1 / -1; }
        label { font-weight: 500; font-size: 0.9rem; }
        body.dark-mode label { color: var(--text-secondary-dark); }
        body.light-mode label { color: var(--text-secondary-light); }
        input, select { padding: 0.8rem 1rem; border-radius: 8px; font-size: 1rem; font-family: 'Poppins', sans-serif; transition: border-color 0.3s, box-shadow 0.3s; }
        body.dark-mode input, body.dark-mode select { border: 1px solid var(--card-border-dark); background-color: rgba(0,0,0,0.2); color: var(--text-primary-dark); }
        body.light-mode input, body.light-mode select { border: 1px solid var(--card-border-light); background-color: #F8F9FA; color: var(--text-primary-light); }
        body.dark-mode input:focus, body.dark-mode select:focus { outline: none; border-color: var(--accent-gold-dark); box-shadow: 0 0 0 3px rgba(201, 176, 55, 0.2); }
        body.light-mode input:focus, body.light-mode select:focus { outline: none; border-color: var(--accent-gold-light); box-shadow: 0 0 0 3px rgba(181, 149, 0, 0.2); }
        input[type="date"]::-webkit-calendar-picker-indicator { filter: invert(1); }
        body.light-mode input[type="date"]::-webkit-calendar-picker-indicator { filter: none; }
        .submit-btn { 
            grid-column: 1 / -1; 
            background: var(--accent-gold-dark);
            color: #000; /* Teks hitam agar kontras dengan emas */
            border: none; 
            cursor: pointer; 
            font-weight: 600; 
            font-size: 1.1rem; 
            padding: 1rem; 
            border-radius: 8px; 
            transition: transform 0.2s, box-shadow 0.3s; 
            box-shadow: 0 0 15px rgba(212, 175, 55, 0.4);
        }
        .submit-btn:hover { 
            transform: translateY(-2px);
            box-shadow: 0 4px 20px rgba(212, 175, 55, 0.6);
        }
        
        /* Table Styles */
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 1rem; text-align: left; vertical-align: middle; }
        body.dark-mode th, body.dark-mode td { border-bottom: 1px solid var(--card-border-dark); }
        body.light-mode th, body.light-mode td { border-bottom: 1px solid var(--card-border-light); }
        th { font-weight: 600; font-size: 0.9rem; text-transform: uppercase; }
        body.dark-mode th { color: var(--text-secondary-dark); }
        body.light-mode th { color: var(--text-secondary-light); }
        th.sortable a { text-decoration: none; display: flex; align-items: center; gap: 0.5rem; }
        body.dark-mode th.sortable a { color: var(--text-secondary-dark); }
        body.light-mode th.sortable a { color: var(--text-secondary-light); }
        body.dark-mode th.sortable a:hover { color: var(--accent-gold-dark); }
        body.light-mode th.sortable a:hover { color: var(--accent-gold-light); }
        .debit { color: var(--debit-color); font-weight: 600; }
        .credit { color: var(--credit-color); font-weight: 600; }
        
        /* Summary & Nav */
        .summary, .main-nav { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem; text-align: center; }
        .summary .card, .main-nav .card { padding: 1.5rem; }
        .summary h3, .main-nav h3 { margin-top: 0; font-size: 1rem; font-weight: 500; }
        body.dark-mode .summary h3, body.dark-mode .main-nav h3 { color: var(--text-secondary-dark); }
        body.light-mode .summary h3, body.light-mode .main-nav h3 { color: var(--text-secondary-light); }
        .summary p { margin-bottom: 0; font-size: 1.8rem; font-weight: 600; }
        .main-nav a { text-decoration: none; }
        .main-nav .card { text-align: center; font-size: 1.2rem; font-weight: 600; transition: transform 0.2s, box-shadow 0.2s; }
        body.dark-mode .main-nav .card { color: var(--text-primary-dark); }
        body.light-mode .main-nav .card { color: var(--text-primary-light); }
        .main-nav .card:hover { transform: translateY(-5px); }
        body.dark-mode .main-nav .card:hover { box-shadow: 0 8px 20px rgba(201, 176, 55, 0.2); border-color: var(--accent-gold-dark); }
        body.light-mode .main-nav .card:hover { box-shadow: 0 8px 20px rgba(0,0,0,0.15); border-color: var(--accent-gold-light); }

        /* Highlighted Numbers */
        .highlight-number.debit { color: var(--debit-color); text-shadow: 0 0 10px rgba(46, 204, 113, 0.7); }
        .highlight-number.credit { color: var(--credit-color); text-shadow: 0 0 10px rgba(231, 76, 60, 0.7); }
        .highlight-number.saldo { color: #fff; text-shadow: 0 0 10px var(--accent-gold-dark), 0 0 2px #333; }

        /* Alert */
        .alert { padding: 1rem; margin-bottom: 1.5rem; border-radius: 8px; font-weight: 500; text-align: center; opacity: 1; transition: opacity 0.5s ease-out; }
        .alert-sukses { background-color: rgba(46, 204, 113, 0.2); color: var(--debit-color); }
        .alert-gagal { background-color: rgba(231, 76, 60, 0.2); color: var(--credit-color); }
        
        .actions-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
    </style>
</head>
<body>
    <div class="theme-switcher">
        <button id="theme-toggle" class="btn icon-btn">🌙</button>
    </div>
    <div class="container">
