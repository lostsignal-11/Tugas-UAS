<?php
session_start();

// --- KONEKSI DATABASE & LOGIKA UTAMA ---
require_once 'partials/db_logic.php';

// --- ROUTING HALAMAN ---
$page = $_GET['page'] ?? 'home';

switch ($page) {
    case 'history':
        $page_file = 'pages/history.php';
        $page_title = 'RIWAYAT TRANSAKSI';
        break;
    case 'graph':
        $page_file = 'pages/graph.php';
        $page_title = 'GRAFIK SALDO';
        break;
    default:
        $page_file = 'pages/home.php';
        $page_title = 'MAALI';
        break;
}

// --- TAMPILKAN HALAMAN ---
require_once 'partials/header.php';
if (file_exists($page_file)) {
    require_once $page_file;
} else {
    echo "<p>Halaman tidak ditemukan.</p>";
}
require_once 'partials/footer.php';